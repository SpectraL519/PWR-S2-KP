var searchData=
[
  ['main_0',['main',['../class_binary_tree_client.html#a9054377038ded44b9b38c741cb1a4efe',1,'BinaryTreeClient.main()'],['../class_binary_tree_server.html#ae6a7292cf6f264bcddf73566cade6e5e',1,'BinaryTreeServer.main()']]]
];
